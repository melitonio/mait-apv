using MAIT.Interfaces;
using Entities;
using Dto;

namespace Interfaces;

public interface IApvService : ICrudService<Apv>
{

}