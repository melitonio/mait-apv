using MAIT.Interfaces;
using Entities;

namespace Interfaces;

public interface IApvService : ICrudService<Apv>;