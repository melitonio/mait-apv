using MAIT.Interfaces;

namespace Entities;

public class Localizacion : BaseEntity
{

}